"""Boards definition from Xunlong Orange Pi"""
