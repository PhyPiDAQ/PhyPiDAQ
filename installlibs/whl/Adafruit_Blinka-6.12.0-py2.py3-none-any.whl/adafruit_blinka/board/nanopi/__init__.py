"""Board definitions from NanoPi"""
